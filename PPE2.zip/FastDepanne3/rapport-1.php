<!DOCTYPE html>
<html>
<head>
	<title>Connexion Profil</title>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style/style1.css">
</head>
<body class="connexion-1">
	<nav class="navbar navbar-expand-lg navbar-dark bg-info navbar2">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
	  	<a class="navbar-brand" href="#">FastDepanne</a>
	  	<div class="collapse navbar-collapse" id="navbarTogglerDemo03">
	    	<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
	      		<li class="nav-item active">
	        		<a class="nav-link" href="accueil.php">Accueil<span class="sr-only">(current)</span></a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link " href="signaler-1.php" tabindex="-1" >Signaler</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link " href="#" tabindex="-1" >Rapport</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link" href="#" tabindex="-1">Ajouter</a>
		      	</li>
		    </ul>
	    	<div class="form-inline">
		    	<ul class="navbar-nav">
      				<li class="nav-item">
        				<a class="nav-link" href="connexion-1.php">Connexion</a>
      				</li>
      			</ul>
			</div>
	  	</div>
	</nav>
	<div class="container block">
		<div class="container formulaire">
			<form method="post" action=""> 		
				<div>
					<div class="titre">
					<h1 class="text-dark">Votre profil :</h1>
					</div>
					<div class="choix">
						<input type="radio" name="profil" id="prof" value="prof"><label class="text-dark" for="prof">Professeur</label><br>
						<input type="radio" name="profil" id="tech" value="tech"><label class="text-dark" for="tech">Technicien</label><br>
						<input type="radio" name="profil" id="eleve" value="eleve"><label class="text-dark" for="eleve">Elève</label>
					</div>
					<div class="valider">
						<input type="submit" value="Valider" class="btn btn-outline-secondary" name="formProfil">
					</div><br>
					<?php
						if (isset($erreur)) {
							echo '<div class="alert alert-danger" role="alert">'.$erreur.'</div>';

						}
						if (isset($action)) {
							echo $action;
						}
					?>
				</div>
			</form>
		</div>
	</div>
	<div class="container-fluid piedPage">
		<div class="row">
			<div class="col-lg-3">
				<div class="case">
					<h3>FASTCORP</h3>
					<br><br>
					Lycée felix le dantec<br>
					Rue des Cordiers • BP 80349<br>
					2303 Lannion cedex<br>
					<strong class="text-danger">Tel.02 96 05 61 71</strong>
					<br><br><br>
					<div class="row">
						<div class="col-lg-6">
							<a href="#" class="text-light">Condition generale d'utitlisation</a>
						</div>
						<div class="col-lg-6">
							<a href="#" class="text-light">Confidentialiter</a>
						</div>					
					</div>				
				</div>		
			</div>
			<div class="col-mg-3">
				<div class="case">
					<h3>FastDepanne</h3><br><br>
					<h6>Contact</h6><br>
					<a href="#" class="text-light">Facebook</a><br>
					<a href="#" class="text-light">Gmail</a><br>
					<a href="#" class="text-light">Instagram</a><br>
					<a href="#" class="text-light">Twiter</a><br>
				</div>	
			</div>
			<div class="col-mg-3">
				<div class="case">
					<img src="image/logo_blanc_felix_ledantec.png" class="img-fluid" alt="Responsive image">
				</div>
			</div>
			<div class="col-mg-3">
				<div>
					&nbsp;
				</div>
			</div>
		</div>
	</div>
</body>