<?php
session_start();
if ($_SESSION['typepbl'] == "perif") {
	$_SESSION['orgpbl'] = $_SESSION['typeperif'];
}
elseif($_SESSION['typepbl'] == "ordi"){
	$_SESSION['orgpbl'] = $_SESSION['typeordi'];
}
elseif ($_SESSION['typepbl'] == "log") {
	$_SESSION['orgpbl'] = $_SESSION['typelog'];
}
elseif ($_SESSION['typepbl'] == "reseau") {
	$_SESSION['orgpbl'] = $_SESSION['typereseau'];
}


if (isset($_POST['formLog'])) {
	if (!empty($_POST['nomSalle']) AND !empty($_POST['nomPC'])) {
		$_SESSION['nomSalle'] = $_POST['nomSalle'];
		$_SESSION['nomPC'] = $_POST['nomPC'];
		$_SESSION['remarque'] = $_POST['remarque'];
		if (isset($_SESSION['orgpbl2'])) {
			header('Location: signaler-3.php?typepbl='.$_SESSION['typepbl'].'&orgpbl='.$_SESSION['orgpbl'].'&orgpbl2='.$_SESSION['orgpbl2']);
	        exit();
		}
		else{
			header('Location: signaler-3.php?typepbl='.$_SESSION['typepbl'].'&orgpbl='.$_SESSION['orgpbl']);
	        exit();
		}
	}
	else{
		$erreur = "Vous devez compléter tout les champs";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Plus d'information</title>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style/style2.css">
</head>
<body class="connexion-1">
	<nav class="navbar navbar-expand-lg navbar-dark bg-info navbar2">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
	  	<a class="navbar-brand" href="#">FastDepanne</a>
	  	<div class="collapse navbar-collapse" id="navbarTogglerDemo03">
	    	<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
	      		<li class="nav-item active">
	        		<a class="nav-link" href="accueil.php">Accueil<span class="sr-only">(current)</span></a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link" href="signaler-1.php" tabindex="-1">Signaler</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Rapport</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Ajouter</a>
		      	</li>
		    </ul>
	  	</div>
	</nav>
	<div class="container block">
		<div class="container formulaire">
			<form method="post" action=""> 		
				<div>
					<div class="titre">
					<h1 class="text-dark">Plus d'information</h1>
					</div>
					<div class="choix">
						<label class="text-dark" >Entrer le numero de la salle :</label><br>
						<input type="text" name="nomSalle" class="form-control" placeholder="num. salle"><br>
						<label class="text-dark" >Entrer le numero ou le nom du PC :</label><br>
						<input type="text" name="nomPC" class="form-control" placeholder="num. PC"><br>
						<label class="text-dark" >Entrer des remarques :*</label><br>
						 <textarea class="form-control" rows="3" placeholder="Remarque :" value="" name="remarque"></textarea>
						 <small class="form-text text-muted"> Les remarques sont facultatifs</small><br>
					</div>
					<div class="valider">
						<input type="submit" value="Valider" class="btn btn-outline-secondary" name="formLog">
					</div><br>
					<?php
						if (isset($erreur)) {
							echo '<div class="alert alert-danger" role="alert">'.$erreur.'</div>';
						}
					?>
				</div>
			</form>
		</div>
	</div>
	<div class="container-fluid piedPage">
		<div class="row">
			<div class="col-lg-3">
				<div class="case">
					<h3>FASTCORP</h3>
					<br><br>
					Lycée felix le dantec<br>
					Rue des Cordiers • BP 80349<br>
					2303 Lannion cedex<br>
					<strong class="text-danger">Tel.02 96 05 61 71</strong>
					<br><br><br>
					<div class="row">
						<div class="col-lg-6">
							<a href="#" class="text-light">Condition generale d'utitlisation</a>
						</div>
						<div class="col-lg-6">
							<a href="#" class="text-light">Confidentialiter</a>
						</div>					
					</div>				
				</div>		
			</div>
			<div class="col-mg-3">
				<div class="case">
					<h3>FastDepanne</h3><br><br>
					<h6>Contact</h6><br>
					<a href="#" class="text-light">Facebook</a><br>
					<a href="#" class="text-light">Gmail</a><br>
					<a href="#" class="text-light">Instagram</a><br>
					<a href="#" class="text-light">Twiter</a><br>
				</div>	
			</div>
			<div class="col-mg-3">
				<div class="case">
					<img src="image/logo_blanc_felix_ledantec.png" class="img-fluid" alt="Responsive image">
				</div>
			</div>
			<div class="col-mg-3">
				<div>
					&nbsp;
				</div>
			</div>
		</div>
	</div>
</body>
