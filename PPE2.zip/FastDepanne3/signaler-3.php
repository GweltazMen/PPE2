<?php

session_start();

try {
    $bdd = new PDO('mysql:host=127.0.0.1;dbname=PPE2', 'PPE2', 'Btssio2017');
} 
catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage() . "<br/>";
}
/*----------Accent---------------*/
function skip_accents( $str, $charset='utf-8' ) {
 
    $str = htmlentities( $str, ENT_NOQUOTES, $charset );
    
    $str = preg_replace( '#&([A-za-z])(?:acute|cedil|caron|circ|grave|orn|ring|slash|th|tilde|uml);#', '\1', $str );
    $str = preg_replace( '#&([A-za-z]{2})(?:lig);#', '\1', $str );
    $str = preg_replace( '#&[^;]+;#', '', $str );
    
    return $str;
}

/*----------Logiciel------------------*/
if ($_SESSION['typepbl'] == "log") {
	$typepbl = "Logicel";
	if ($_SESSION['orgpbl'] == "Office") {
		$orgpbl = "LibreOffice";
	}
	elseif ($_SESSION['orgpbl'] == "nav") {
		$orgpbl = "Navigateur";
	}
	elseif ($_SESSION['orgpbl'] == "windows") {
		$orgpbl = "Windows";
	}
	else{
		$orgpbl = $_SESSION['orgpbl'];
	}
}
/*------------------Ordinateur----------------*/
elseif ($_SESSION['typepbl'] == "ordi"){
	$typepbl = "Ordinateur";
	if ($_SESSION['orgpbl'] == "pblAlim") {
		$orgpbl = "Problème d'Alimentation";
	}
	elseif ($_SESSION['orgpbl'] == "winOff") {
		$orgpbl = "Windows n'arrrive pas à démarer";
	}
	elseif ($_SESSION['orgpbl'] == "pblwin") {
		$orgpbl = "Windows est très lent";
	}
	elseif ($_SESSION['orgpbl'] == "message") {
		$orgpbl = "Un message d'erreur s'affiche avant Windows";
	}
}
/*---------------Periferique-----------------*/
elseif ($_SESSION['typepbl'] == "perif"){
	$typepbl = "Périférique";
	$orgpbl = $_SESSION['orgpbl'];
	if ($_SESSION['orgpbl2'] == "degrad") {
		$etatperif = "Dégradation";
	}
	elseif ($_SESSION['orgpbl2'] == "dispa") {
		$etatperif = "Disparition";
	}
	elseif ($_SESSION['orgpbl2'] == "fonct") {
		$etatperif = "Ne fonctionne pas";
	}
}
/*-----------------Reseaux-----------------------*/
elseif ($_SESSION['typepbl'] == "reseau"){
	$typepbl = "Réseaux";
	if ($_SESSION['orgpbl'] == "pblInt") {
		$orgpbl = "Lenteur de la connexion Internet";
	}
	elseif ($_SESSION['orgpbl'] == "pasInt"); {
		$orgpbl = "Pas de connexion Internet";
	}
}

/*----------Envoie dans la bdd--------------*/
$newTypepbl = skip_accents($typepbl);
$newOrgpbl = skip_accents($orgpbl);
$dateSignal = date("j, n, Y");


if (isset($_POST['formMessage'])) {//-------TEST POUR SAVOIR SI CE PROBLEME EXISTE

	$reqsignal = $bdd->prepare("SELECT * FROM signaler WHERE typepbl = ? AND orgpbl = ? AND numSalle = ? AND nomOrdi = ? AND dateSignal = ?");
	$reqsignal->execute(array($newTypepbl , $newOrgpbl, $_SESSION['nomSalle'], $_SESSION['nomPC'], $dateSignal));
	$signalexist = $reqsignal->rowCount();

	if ($signalexist == 1) {
		$valider = "Merci beaucoup ! Mais ce problème a déjà été signaler . Cliquez <a href='accueil.php'>ici</a> pour revenir à l'accueil.";
	}
	else{
		$insertuser = $bdd -> prepare("INSERT INTO `signaler`(`typepbl`, `orgpbl`, `numSalle`, `nomOrdi`, `dateSignal`) VALUES (?,?,?,?,?)");
				$insertuser->execute(array($newTypepbl, $newOrgpbl, $_SESSION['nomSalle'], $_SESSION['nomPC'], $dateSignal));
		$valider = "Message envoyer ! Cliquez <a href='accueil.php'>ici</a> pour revenir à l'accueil.";
	}
}


/*-------------ENVOIE MAIL-------------*/
$mail = "alan.pere.fr@gmail.com";

if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $mail))
{
	$passage_ligne = "\r\n";
}
else
{
	$passage_ligne = "\n";
}
//=========Declaration des messages
$message_html = "<html><head></head><body><b>Salut à tous</b>, voici un e-mail envoyé par un <i>script PHP</i>.</body></html>";
//===========================

//=========Declaration du boundary
$boundary = "-----=".md5(rand());
//============================

//==================Sujet
$sujet = "Hey broo";
//====================

//=====Création du header de l'e-mail
$header = "From: \"ouai nan\"<alan.pere.fr@gmail.com>".$passage_ligne;
$header .= "Reply-to: \"ouai nan\" <alan.pere.fr@gmail.com>".$passage_ligne;
$header .= "MIME-Version: 1.0".$passage_ligne;
$header .= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"$boundary\"".$passage_ligne;
//==========

//=======Creation du message
$message = $passage_ligne."--".$boundary.$passage_ligne;
//=======Ajout message format html
$message .= "Content-Type: text/html; charset=\"ISO-8859-1\"".$passage_ligne;
$message .= "Content-Transfer-Encoding: 8bit".$passage_ligne;
$message.= $passage_ligne.$message_html.$passage_ligne;
//==========
$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
$message.= $passage_ligne."--".$boundary."--".$passage_ligne;
//==========
 
//=====Envoi de l'e-mail.
mail($mail,$sujet,$message,$header);
//==========





?>

<!DOCTYPE html>
<html>
<head>
	<title>Signaler Problème</title>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style/style2.css">
</head>
<body class="connexion-1">
	<nav class="navbar navbar-expand-lg navbar-dark bg-info navbar2">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
	  	<a class="navbar-brand" href="#">FastDepanne</a>
	  	<div class="collapse navbar-collapse" id="navbarTogglerDemo03">
	    	<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
	      		<li class="nav-item active">
	        		<a class="nav-link" href="accueil.php">Accueil<span class="sr-only">(current)</span></a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link" href="signaler-1.php" tabindex="-1">Signaler</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Rapport</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Ajouter</a>
		      	</li>
		    </ul>
	  	</div>
	</nav>
	<div class="container block">
		<div class="container formulaire">
			<form method="post" action=""> 		
				<div class="titre">
					<h1 class="text-dark">Envoie message</h1>
				</div>
				<div class="choix">
					<?php
					echo "L'ordinateur : ".$_SESSION['nomPC']."<br>Salle : ".$_SESSION['nomSalle']."<br>Type Problème : ".$typepbl."<br>";
					if ($_SESSION['typepbl'] == "log") {//---Logicel
						echo "Nom du logicel : ".$orgpbl."<br>".$orgpbl." est defaillant<br>";
					}
					elseif ($_SESSION['typepbl'] == "ordi") {//---Ordinateur
						echo "Origine du Problème : ".$orgpbl."<br>";
					}
					elseif ($_SESSION['typepbl'] == "perif") {//---Periferique
						echo "Type de Périférique : ".$orgpbl."<br> Problème : ".$etatperif."<br>";
					}
					elseif ($_SESSION['typepbl'] == "reseau") {//---Reseau
						echo "Connexion : ".$orgpbl."<br>";
					}

					if (!empty($_SESSION['remarque'])) {
						echo "Remarque : ".$_SESSION['remarque'];
					}
					?>
				</div>
				<div class="valider">
						<input type="submit" value="Envoyer" class="btn btn-outline-secondary" name="formMessage">
				</div><br>
				<?php
					if (isset($valider)) {
						echo '<div class="alert alert-success" role="alert">'.$valider.'</div>';
					}
				?>
			</form>
		</div>
	</div>
	<div class="container-fluid piedPage">
		<div class="row">
			<div class="col-lg-3">
				<div class="case">
					<h3>FASTCORP</h3>
					<br><br>
					Lycée felix le dantec<br>
					Rue des Cordiers • BP 80349<br>
					2303 Lannion cedex<br>
					<strong class="text-danger">Tel.02 96 05 61 71</strong>
					<br><br><br>
					<div class="row">
						<div class="col-lg-6">
							<a href="#" class="text-light">Condition generale d'utitlisation</a>
						</div>
						<div class="col-lg-6">
							<a href="#" class="text-light">Confidentialiter</a>
						</div>					
					</div>				
				</div>		
			</div>
			<div class="col-mg-3">
				<div class="case">
					<h3>FastDepanne</h3><br><br>
					<h6>Contact</h6><br>
					<a href="#" class="text-light">Facebook</a><br>
					<a href="#" class="text-light">Gmail</a><br>
					<a href="#" class="text-light">Instagram</a><br>
					<a href="#" class="text-light">Twiter</a><br>
				</div>	
			</div>
			<div class="col-mg-3">
				<div class="case">
					<img src="image/logo_blanc_felix_ledantec.png" class="img-fluid" alt="Responsive image">
				</div>
			</div>
			<div class="col-mg-3">
				<div>
					&nbsp;
				</div>
			</div>
		</div>
	</div>
</body>