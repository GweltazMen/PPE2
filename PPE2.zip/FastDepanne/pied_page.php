<div class="container-fluid piedPage">
		<div class="row">
			<div class="col-lg-3">
				<div class="case">
					<h3>FASTCORP</h3>
					<br><br>
					Lycée felix le dantec<br>
					Rue des Cordiers • BP 80349<br>
					2303 Lannion cedex<br>
					<strong class="text-danger">Tel.02 96 05 61 71</strong>
					<br><br><br>
					<div class="row">
						<div class="col-lg-6">
							<a href="#" class="text-light">Condition generale d'utitlisation</a>
						</div>
						<div class="col-lg-6">
							<a href="#" class="text-light">Confidentialiter</a>
						</div>					
					</div>				
				</div>		
			</div>
			<div class="col-mg-3">
				<div class="case">
					<h3>FastDepanne</h3><br><br>
					<h6>Contact</h6><br>
					<a href="#" class="text-light">Facebook</a><br>
					<a href="#" class="text-light">Gmail</a><br>
					<a href="#" class="text-light">Instagram</a><br>
					<a href="#" class="text-light">Twiter</a><br>
				</div>	
			</div>
			<div class="col-mg-3">
				<div class="case">
					<img src="image/logo_blanc_felix_ledantec.png" class="img-fluid" alt="Responsive image">
				</div>
			</div>
			<div class="col-mg-3">
				<div>
					&nbsp;
				</div>
			</div>
		</div>
	</div>