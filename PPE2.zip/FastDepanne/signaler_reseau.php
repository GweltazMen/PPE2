<?php
session_start();

if (isset($_POST['formReseau'])) {
	if (!empty($_POST['typeReseau'])) {
		$_SESSION['typereseau'] = $_POST['typeReseau'];
		header("Location: signaler-2.php?typepbl=".$_SESSION['typepbl']);
		exit();
				
	}
	else{
		$erreur = "Vous devez cocher l'un des type de problème";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Problème Réseaux</title>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style/style2.css">
</head>
<body class="connexion-1">
	<nav class="navbar navbar-expand-lg navbar-dark bg-info navbar2">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
	  	<a class="navbar-brand" href="#">FastDepanne</a>
	  	<div class="collapse navbar-collapse" id="navbarTogglerDemo03">
	    	<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
	      		<li class="nav-item active">
	        		<a class="nav-link" href="accueil.php">Accueil<span class="sr-only">(current)</span></a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link" href="signaler-1.php" tabindex="-1">Signaler</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Rapport</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Ajouter</a>
		      	</li>
		    </ul>
	  	</div>
	</nav>
	<div class="container block">
		<div class="container formulaire">
			<form method="post" action=""> 		
				<div>
					<div class="titre">
					<h1 class="text-dark">Type de problème :</h1>
					</div>
					<div class="choix">
						<input type="radio" name="typeReseau" value="pblInt" id="pblInt"><label class="text-dark" for="pblInt">Lenteur d'internet</label><br>
						<input type="radio" name="typeReseau" value="pasInt" id="pasInt"><label class="text-dark" for="pasInt">Pas d'internet</label><br>
					</div>
					<div class="valider">
						<input type="submit" value="Valider" class="btn btn-outline-secondary" name="formReseau">
					</div><br>
					<?php
						if (isset($erreur)) {
							echo '<div class="alert alert-danger" role="alert">'.$erreur.'</div>';
						}
					?>
				</div>
			</form>
		</div>
	</div>
	<?php
	require("pied_page.php");
	?>
</body>
</html>