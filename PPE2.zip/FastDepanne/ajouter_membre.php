<?php

require("connexionBDD.php");

if (isset($_POST['formInscri'])) {
	if (!empty($_POST['nom']) AND !empty($_POST['prenom']) AND !empty($_POST['id']) AND !empty($_POST['mdp']) AND !empty($_POST['mdp2'])) {

		$nom = $_POST['nom'];
		$prenom = $_POST['prenom']; 
		$id = $_POST['id'];
		$mdp = $_POST['mdp'];
		$mdp2 = $_POST['mdp2'];

		if ($mdp == $mdp2) {
			if (preg_match('#^(?=.*[a-z])(?=.*[A-Z])(?=.*\W)(?=.*[0-9]{2,}).{8,}$#', $mdp)) {
				$mpd_hash = password_hash($mdp, PASSWORD_DEFAULT);

				$insertuser = $bdd -> prepare("INSERT INTO `professeur`(`nom`, `prenom`, `pseudo`, `mdp`) VALUES (?,?,?,?)");
				$insertuser->execute(array($nom, $prenom, $id, $mpd_hash));
				$valider = "Ce compte a bien etait créer ! Cliquez <a href='accueil.php'>ici</a> pour revenir à l'accueil.";
			}
			else{
				$erreur = "Le mot de passe doit comporter au minimum 8 caractères et au moins une majuscule, une minuscule, 2 chiffres et un caractère spécial";
			}
		}
		else{
			$erreur = "Les deux mots de passe ne corresponde pas ";
		}
	}
	else{
		$erreur = "Vous devez remplir tous les champs";
	}
}

?>


<!DOCTYPE html>
<html>
<head>
	<title>Connexion Profil</title>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style/style2.css">
</head>
<body class="connexion-1">
	<nav class="navbar navbar-expand-lg navbar-dark bg-info navbar2">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
	  	<a class="navbar-brand" href="#">FastDepanne</a>
	  	<div class="collapse navbar-collapse" id="navbarTogglerDemo03">
	    	<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
	      		<li class="nav-item active">
	        		<a class="nav-link" href="accueil.php">Accueil<span class="sr-only">(current)</span></a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Signaler</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Ajouter</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link" href="#">Contact</a>
		      	</li>
		    </ul>
	    	<div class="form-inline">
		    	<ul class="navbar-nav">
      				<li class="nav-item">
        				<a class="nav-link" href="connexion-1.php">Connexion</a>
      				</li>
      			</ul>
			</div>
	  	</div>
	</nav>


	<div class="container block">
		<div class="container formulaire">
			<form method="post" action=""> 		
				<div>
					<div class="titre">
					<h1 class="text-dark">Ajouter Membre</h1>
					</div>
					<div class="choix">
						<div class="row">
							<div class="col-md-6">
								<label>Nom</label>
								<input type="text" class="form-control" name="nom" placeholder="Entrer nom">
							</div>
							<div class="col-md-6">
								<label>Prenom</label>
								<input type="text" class="form-control" name="prenom" placeholder="Entrer prenom"><br>
							</div>
						</div>
						<label for="exampleInputEmail1">Identifiant</label>
    					<input type="text" class="form-control" name="id" placeholder="Entrer Identifiant">
    					<small class="form-text text-muted">L'identifiant doit être la première lettre du prenom puis le nom</small><br>
						<label for="exampleInputPassword1">Mot de passe</label>
    					<input type="password" name="mdp" class="form-control" id="exampleInputPassword1" placeholder="Mot de passe"><br>
    					<label for="exampleInputPassword1">Confirmer mot de passe</label>
    					<input type="password" name="mdp2" class="form-control" id="exampleInputPassword1" placeholder="Confirmation"><br>
					</div>
					<div class="valider">
						<input type="submit" value="Valider" class="btn btn-outline-secondary" name="formInscri">
					</div><br>
					<?php
						if (isset($erreur)) {
							echo '<div class="alert alert-danger" role="alert">'.$erreur.'</div>';

						}
						if (isset($valider)) {
							echo '<div class="alert alert-success" role="alert">'.$valider.'</div>';

						}
					?>
				</div>
			</form>
		</div>
	</div>
	<?php
	require("pied_page.php");
	?>
</body>
</html>