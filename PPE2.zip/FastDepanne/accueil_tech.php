<?php

session_start();

try {
    $bdd = new PDO('mysql:host=127.0.0.1;dbname=PPE2', 'root', '');
} 
catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage() . "<br/>";
}

if (isset($_GET['id']) AND $_GET['id'] >= 1 ) {
	$getid = intval($_GET['id']);
	$requser = $bdd->prepare("SELECT * FROM technicien WHERE id = ?");
	$requser->execute(array($getid));
	$userinfo = $requser->fetch();
?>


<!DOCTYPE html>
<html>
<head>
	<title>Accueil</title>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style/style1.css">
</head>
<body class="accueil">
	<nav class="container-fluid bg-info hPage">
		<span class="mb-0 h3 text-light">FASTCORP</span>
	</nav>


	<img src="image/slide01.jpg" class="img-fluid" alt="Responsive image">


	<nav class="navbar navbar-expand-lg navbar-dark bg-info sticky-top navbar2">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
	  	<a class="navbar-brand" href="#">FastDepanne</a>
	  	<div class="collapse navbar-collapse" id="navbarTogglerDemo03">
	    	<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
	      		<li class="nav-item active">
	        		<a class="nav-link" href="#">Accueil<span class="sr-only">(current)</span></a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link" href="signaler-1.php" tabindex="-1">Signaler</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link" href="rapport-1.php" tabindex="-1" >Rapport</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link" href="ajouter_membre" tabindex="-1">Ajouter</a>
		      	</li>
		    </ul>
	    	<div class="form-inline">
		    	<div class="dropdown dropleft">
				  	<a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				    Profil
				  	</a>
				  	<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
					    <a class="dropdown-item" href="#"><?php echo $userinfo['nom']; ?></a>
					    <a class="dropdown-item" href="#"><?php echo $userinfo['prenom']; ?></a>
					    <a class="dropdown-item deconnect" href="deconnexion.php">Deconnecter</a>
				  	</div>
				</div>
			</div>
	  	</div>
	</nav>
	<div class="container graphique">
		<div class="row">
			<div class="col-md-6">
				<img src="image/graph5.jpg" class="img-fluid" alt="Responsive image">
			</div>
			<div class="col-md-6 text1 bg-danger" >
				<p>La degradation du materielle informatique coute très chère à l'établissement. Vous pouvez voir les dépences engendrer par le lycée depuis le debut de l'année dans cette salle.</p>
			</div>
		</div>
	</div>


	<div class="container-fluid graph">
		<div class="row">
			<div class="col-lg-3">
				<div class="case">
					<h3>Periferique</h3>
					<div class="image">
						<a href="#"><img src="image/graph1.jpg"></a>
					</div>
					<p class="text">Les differents problèmes qui concerne les periférique des ordinateur de la salle(souris, claviers ...)<br></p>
				</div>			
			</div>
			<div class="col-lg-3">
				<div class="case">
					<h3>Logiciel</h3>
					<div class="image">
						<a href="#"><img src="image/graph2.jpg"></a>
					</div>
					<p>Les differents problèmes qui concerne les logiciel des ordinateurs de la salle<br><br></p>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="case">
					<h3>Réseaux</h3>
					<div class="image">
						<a href="#"><img src="image/graph3.png"></a>
					</div>
					<p>Les differents problèmes qui concerne le réseaux de la salle<br><br></p>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="case">
					<h3>Ordinateur</h3>
					<div class="image">
						<a href="#"><img src="image/graph4.jpg"></a>
					</div>
					<p>Les differents problèmes qui concerne les ordinateurs de la salle<br><br></p>
				</div>
			</div>
		</div>
	</div>
	<div class="container info1">
		<div class="row">
			<div class="col-lg-6">
				<div class="case">
					<img src="image/icone-ordinateur.png"><br>
					Ce site vous permet de voir les differents problème et degas informatique.<strong>FastDepanne</strong> permet de ressenece tout les incident de cette salle en vous fesant prendre concience du coup et du temps passer par les technicien du lycée.
				</div>			
			</div>
			<div class="col-lg-6">
				<div class="case">
					<img src="image/singing-teacher.png"><br>
					Si vous desirez signaler un problème sur un Ordinateur veuillez prevenir le proffesseur de cette salle.IL devra alors se connecter et suivre les instructions pour pouvoir avertir le technicien.<strong>FastDepanne</strong> avertira automatiquement le technicien et lui indiquera précisement le problème.
				</div>			
			</div>
		</div>
	</div>
	<?php
	require("pied_page.php");
	?>
</body>
</html>
<?php
}
?>