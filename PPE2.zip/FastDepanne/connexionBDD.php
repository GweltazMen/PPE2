<?php

try {
    $bdd = new PDO('mysql:host=127.0.0.1;dbname=PPE2', 'root', '');
} 
catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage() . "<br/>";
}

?>