<?php

session_start();

require("connexionBDD.php");

if (isset($_POST['formConnexion'])) {
	if (!empty($_POST['id']) AND !empty($_POST['mdp'])) {

		$idConnect = $_POST['id'];
		$mdpConnect = $_POST['mdp'];

		$requser = $bdd->prepare("SELECT * FROM technicien WHERE pseudo = ? AND mdp = ?");
		$requser->execute(array($idConnect , $mdpConnect));
		$userexist = $requser->rowCount();
		if ($userexist == 1) {
			$userinfo = $requser->fetch();
			$_SESSION['id'] = $userinfo['id'];
			$_SESSION['pseudo'] = $userinfo['pseudo'];
			$_SESSION['nom'] = $userinfo['nom'];
			$_SESSION['prenom'] = $userinfo['prenom'];
			header('Location: accueil_tech.php?id='.$_SESSION['id']);
        	exit();
		}
		else{
			$erreur = "L'identifiant ou le mot de passe est incorrect";
		}
	}
	else{
		$erreur = "Vous devez remplir tout les champs !";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Connexion Professeur</title>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style/styles.css">
</head>
<body class="connexion-1">
	<nav class="navbar navbar-expand-lg navbar-dark bg-info navbar2">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
	  	<a class="navbar-brand" href="#">FastDepanne</a>
	  	<div class="collapse navbar-collapse" id="navbarTogglerDemo03">
	    	<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
	      		<li class="nav-item active">
	        		<a class="nav-link" href="accueil.php">Accueil<span class="sr-only">(current)</span></a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Signaler</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Rapport</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Ajouter</a>
		      	</li>
		    </ul>
	    	<div class="form-inline">
		    	<ul class="navbar-nav">
      				<li class="nav-item">
        				<a class="nav-link" href="connexion-1.php">Connexion</a>
      				</li>
      			</ul>
			</div>
	  	</div>
	</nav>

	<div class="container block">
		<div class="container formulaire">
			<form method="post" action=""> 		
				<div>
					<div class="titre">
					<h1 class="text-dark">Connexion Technicien :</h1>
					</div>
					<div class="choix">
						<label for="exampleInputEmail1">Identifiant</label>
    					<input type="text" class="form-control" name="id" placeholder="Entrer Identifiant"><br>
						<label for="exampleInputPassword1">Mot de passe</label>
    					<input type="password" name="mdp" class="form-control" id="exampleInputPassword1" placeholder="Mot de passe"><br>
					</div>
					<div class="valider">
						<input type="submit" value="Valider" class="btn btn-outline-secondary" name="formConnexion">
					</div><br>
					<?php
						if (isset($erreur)) {
							echo '<div class="alert alert-danger" role="alert">'.$erreur.'</div>';

						}
					?>
				</div>
			</form>
		</div>
	</div>
	<?php
	require("pied_page.php");
	?>
</body>
</html>