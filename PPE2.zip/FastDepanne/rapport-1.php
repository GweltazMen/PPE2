<?php


require("connexionBDD.php");


session_start();



if(isset($_POST['formidPb'])){
	if (!empty($_POST['idpb'])) {

		$requser = $bdd->prepare("SELECT * FROM signaler WHERE id = ? ");
		$requser->execute(array($_POST['idpb']));
		$resul = $requser->fetch();

		if ($resul) {
			$_SESSION['idpb'] = $_POST['idpb'];
			$_SESSION['typepb']=$resul['typepbl'];
			$_SESSION['originpb']= $resul['orgpbl'];
			header('Location: rapport2.php');
			exit();
		}
		else{

			$erreur= "Cet identifiant de problème n'existe pas.";
		}
		
		
	}
	else{
		$erreur ="Tout les champs doivent etre rempli";
	}
}







?>
<!DOCTYPE html>
<html>
<head>
	<title>Connexion Profil</title>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style/style2.css">
</head>
<body class="connexion-1">
	<nav class="navbar navbar-expand-lg navbar-dark bg-info navbar2">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
	  	<a class="navbar-brand" href="#">FastDepanne</a>
	  	<div class="collapse navbar-collapse" id="navbarTogglerDemo03">
	    	<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
	      		<li class="nav-item active">
	        		<a class="nav-link" href="accueil.php">Accueil<span class="sr-only">(current)</span></a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link " href="signaler-1.php" tabindex="-1" >Signaler</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link " href="#" tabindex="-1" >Rapport</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link" href="#" tabindex="-1">Ajouter</a>
		      	</li>
		    </ul>
	    	<div class="form-inline">
		    	<ul class="navbar-nav">
      				<li class="nav-item">
        				<a class="nav-link" href="connexion-1.php">Connexion</a>
      				</li>
      			</ul>
			</div>
	  	</div>
	</nav>
	<div class="container block">
		<div class="container formulaire">
			<form method="post" action=""> 		
				<div>
					<div class="titre">
					<h1 class="text-dark">Votre profil :</h1>
					</div>
					<div class="choix">
						<label class="text-dark" >Identifiant problème</label><br>
						<input type="text" name="idpb" class="form-control" placeholder="Entrer id problème"><br>
					</div>
					<div class="valider">
						<input type="submit" value="Valider" class="btn btn-outline-secondary" name="formidPb">
					</div><br>
					<?php
						if (isset($erreur)) {
							echo '<div class="alert alert-danger" role="alert">'.$erreur.'</div>';

						}
						
					?>
				</div>
			</form>
		</div>
	</div>
	<?php
	require("pied_page.php")
	?>
</body>